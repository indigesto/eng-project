# README

This README would normally document whatever steps are necessary to get the
application up and running.

Somente um protótipo do BuddyMe, sem pretensões.
