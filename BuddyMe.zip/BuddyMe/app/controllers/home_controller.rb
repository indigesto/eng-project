class HomeController < ApplicationController
  def front
  	Rails.application.routes.draw do
  	root to: 'home#front'
	end
  end
end
